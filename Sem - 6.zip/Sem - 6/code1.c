#include <stdio.h>

void main()
{
    FILE *fp;

    fp = fopen("output.txt", "w");

    fprintf(fp, "Hello World\n");

    fclose(fp);

    printf("Text written to output.txt\n");
}
