#include <stdio.h>

void main()
{

    FILE *fp;

    char ch;
    int chars = 0, spaces = 0, tabs = 0, newLine = 0;
    fp = fopen("output.txt", "r");
    ch = fgetc(fp);
    while (ch != EOF)
    {
        if (ch == '\t')
        {
            tabs++;
        }
        else if (ch == ' ')
        {
            spaces++;
        }
        else if (ch == '\n')
        {
            newLine++;
        }
        else
        {
            chars++;
        }
        ch = fgetc(fp);
    }
    fclose(fp);
    printf("chars = %d\n", chars);
    printf("tabs = %d\n", tabs);
    printf("spaces = %d\n", spaces);
    printf("new line = %d\n", newLine);
}