#include <stdio.h>

void main()
{
    FILE *in, *out;
    char ch;
    int newWord = 1;

    in = fopen("input.txt", "r");
    out = fopen("output.txt", "w");

    while ((ch = fgetc(in)) != EOF)
    {

        if (newWord && ch >= 'a' && ch <= 'z')
        {
            ch = ch - ('a' - 'A');
        }

        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
        {
            newWord = 0;
        }
        else
        {
            newWord = 1;
        }

        fputc(ch, out);
    }

    fclose(in);
    fclose(out);

    printf("Text capitalized from input.txt to output.txt\n");
}
