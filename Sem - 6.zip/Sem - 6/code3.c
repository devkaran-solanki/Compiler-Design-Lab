#include <stdio.h>

void main()
{

    FILE *out, *app;
    out = fopen("output.txt", "a");
    app = fopen("append.txt", "r");

    char ch = fgetc(app);
    while (ch != EOF)
    {
        fputc(ch, out);
        ch = fgetc(app);
    }
    fclose(out);
    fclose(app);

    printf("Text appended to output.txt\n");
}